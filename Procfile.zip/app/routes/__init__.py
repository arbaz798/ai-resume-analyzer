"""
Routes package initialization.

This package contains all the route handlers for the Resume Analyzer application.
"""
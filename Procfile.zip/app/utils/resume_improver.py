"""
Resume Improver Module.

This module implements improvements to resumes based on the analysis results.
It modifies the original document while preserving its format and structure.
"""

import os
import re
import fitz  # PyMuPDF
import docx  # python-docx
from docx.shared import Pt
from pdfminer.high_level import extract_text as pm_extract_text
from app.utils.nlp_utils import get_spacy_model, clean_text
from app.utils.resume_analyzer import WEAK_WORDS, ACTION_VERBS

def replace_text_in_pdf(input_path, output_path, replacements):
    """
    PDF files are not supported for text replacement in this version.
    Please convert your PDF to DOCX format for improvements.
    
    Args:
        input_path (str): Path to the input PDF file.
        output_path (str): Path to save the modified PDF.
        replacements (list): List of tuples (old_text, new_text).
        
    Returns:
        bool: False - PDF editing not supported.
    """
    print("PDF text replacement is not supported. Please upload a DOCX or TXT file for AI improvements.")
    return False

def replace_text_in_docx(input_path, output_path, replacements):
    """
    Replace text in a DOCX file - simplified version that ensures replacements work.
    
    Args:
        input_path (str): Path to the input DOCX file.
        output_path (str): Path to save the modified DOCX.
        replacements (list): List of tuples (old_text, new_text).
        
    Returns:
        bool: True if successful, False otherwise.
    """
    try:
        print(f"DEBUG: Opening DOCX file: {input_path}")
        print(f"DEBUG: Will apply {len(replacements)} replacements")
        
        # Open the docx file
        doc = docx.Document(input_path)
        
        replacement_count = 0
        total_paragraphs = 0
        
        # Process all paragraphs
        for para in doc.paragraphs:
            total_paragraphs += 1
            if para.text.strip():
                original_text = para.text
                new_text = original_text
                
                # Apply all replacements
                for old_text, replacement_text in replacements:
                    if old_text in new_text:
                        before_count = new_text.count(old_text)
                        new_text = new_text.replace(old_text, replacement_text)
                        replacement_count += before_count
                        print(f"DEBUG: In paragraph: '{old_text}' → '{replacement_text}' ({before_count} times)")
                
                # If text was modified, update the paragraph
                if new_text != original_text:
                    # Clear all runs and add new text
                    para.clear()
                    para.add_run(new_text)
        
        # Process all tables
        table_count = 0
        for table in doc.tables:
            table_count += 1
            for row in table.rows:
                for cell in row.cells:
                    for para in cell.paragraphs:
                        if para.text.strip():
                            original_text = para.text
                            new_text = original_text
                            
                            # Apply all replacements
                            for old_text, replacement_text in replacements:
                                if old_text in new_text:
                                    before_count = new_text.count(old_text)
                                    new_text = new_text.replace(old_text, replacement_text)
                                    replacement_count += before_count
                                    print(f"DEBUG: In table cell: '{old_text}' → '{replacement_text}' ({before_count} times)")
                            
                            # If text was modified, update the paragraph
                            if new_text != original_text:
                                para.clear()
                                para.add_run(new_text)
        
        print(f"DEBUG: Processed {total_paragraphs} paragraphs and {table_count} tables")
        print(f"DEBUG: Made {replacement_count} total replacements")
        
        # Save the modified document
        doc.save(output_path)
        print(f"DEBUG: DOCX saved to: {output_path}")
        
        # Verify the file was created
        if os.path.exists(output_path):
            file_size = os.path.getsize(output_path)
            print(f"DEBUG: Output file size: {file_size} bytes")
            return True
        else:
            print("DEBUG: Output file was not created!")
            return False
        
    except Exception as e:
        print(f"Error replacing text in DOCX: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def replace_text_in_txt(input_path, output_path, replacements):
    """
    Replace text in a plain text file.
    
    Args:
        input_path (str): Path to the input text file.
        output_path (str): Path to save the modified text file.
        replacements (list): List of tuples (old_text, new_text).
        
    Returns:
        bool: True if successful, False otherwise.
    """
    try:
        # Read the file content
        with open(input_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        # Apply replacements
        for old_text, new_text in replacements:
            content = content.replace(old_text, new_text)
        
        # Write the modified content
        with open(output_path, 'w', encoding='utf-8') as file:
            file.write(content)
        
        return True
    except UnicodeDecodeError:
        # Try with different encodings if utf-8 fails
        try:
            with open(input_path, 'r', encoding='latin-1') as file:
                content = file.read()
            
            # Apply replacements
            for old_text, new_text in replacements:
                content = content.replace(old_text, new_text)
            
            # Write the modified content
            with open(output_path, 'w', encoding='latin-1') as file:
                file.write(content)
            
            return True
        except Exception as e:
            print(f"Error replacing text in TXT with latin-1 encoding: {str(e)}")
            return False
    except Exception as e:
        print(f"Error replacing text in TXT: {str(e)}")
        return False

def improve_weak_language(text, analysis_results):
    """
    AI-powered language improvement using NLP analysis and contextual replacements.
    
    Args:
        text (str): The original resume text.
        analysis_results (dict): Resume analysis results.
        
    Returns:
        list: List of tuples (old_text, new_text) for replacement.
    """
    replacements = []
    
    print(f"DEBUG: Starting AI-powered text improvement...")
    print(f"DEBUG: Text length: {len(text)} characters")
    
    # Allow improvement of any non-empty text
    if not text.strip():
        print("DEBUG: Text is empty, no improvements possible")
        return []
    
    try:
        # Get NLP model for intelligent analysis
        nlp = get_spacy_model()
        
        # Process with spaCy (works with any length text)
        doc = nlp(text)
        print(f"DEBUG: spaCy processed {len(doc)} tokens")
        
        # AI-powered improvements based on context
        replacements.extend(improve_weak_verbs_with_ai(doc, text))
        replacements.extend(improve_weak_adjectives_with_ai(doc, text))
        replacements.extend(improve_weak_phrases_with_ai(doc, text))
        replacements.extend(remove_filler_words_with_ai(doc, text))
        replacements.extend(enhance_professional_language_with_ai(doc, text))
        replacements.extend(improve_lorem_ipsum_with_ai(text))
        
        # Always add basic improvements as well
        replacements.extend(get_basic_improvements(text))
        
    except Exception as e:
        print(f"DEBUG: AI processing failed, using fallback improvements: {e}")
        # Fallback to basic improvements if AI fails
        replacements.extend(get_basic_improvements(text))
    
    # Remove duplicates while preserving order
    unique_replacements = []
    seen = set()
    for old_text, new_text in replacements:
        if (old_text, new_text) not in seen and old_text != new_text:
            unique_replacements.append((old_text, new_text))
            seen.add((old_text, new_text))
    
    print(f"DEBUG: Generated {len(unique_replacements)} AI-powered improvements")
    return unique_replacements


def improve_weak_verbs_with_ai(doc, text):
    """Use AI to identify and improve weak verbs based on context."""
    replacements = []
    
    # AI-driven verb improvements based on context
    weak_verb_patterns = {
        'helped': 'facilitated',
        'assisted': 'supported', 
        'handled': 'managed',
        'did': 'executed',
        'made': 'created',
        'used': 'utilized',
        'got': 'achieved',
        'took': 'assumed',
        'gave': 'provided',
        'put': 'implemented',
        'showed': 'demonstrated',
        'told': 'communicated',
        'worked': 'operated',
        'tried': 'strived',
        'looked': 'analyzed',
        'found': 'identified',
        'kept': 'maintained'
    }
    
    for token in doc:
        if token.pos_ == "VERB" and token.lemma_ in weak_verb_patterns:
            # Context-aware replacement
            original = token.text
            improved = weak_verb_patterns[token.lemma_]
            
            # Preserve tense and form
            if original.endswith('ed'):
                improved += 'd' if improved.endswith('e') else 'ed'
            elif original.endswith('ing'):
                improved = improved.rstrip('e') + 'ing'
            elif original.endswith('s') and not original.endswith('ss'):
                improved += 's'
            
            if original in text:
                replacements.append((original, improved))
                print(f"DEBUG: AI verb improvement: '{original}' → '{improved}'")
    
    return replacements


def improve_weak_adjectives_with_ai(doc, text):
    """Use AI to identify and improve weak adjectives."""
    replacements = []
    
    weak_adj_patterns = {
        'good': 'exceptional',
        'great': 'outstanding',
        'nice': 'excellent', 
        'okay': 'satisfactory',
        'fine': 'proficient',
        'basic': 'fundamental',
        'simple': 'streamlined',
        'big': 'substantial',
        'small': 'focused',
        'hard': 'challenging',
        'easy': 'efficient',
        'bad': 'challenging',
        'old': 'established',
        'new': 'innovative'
    }
    
    for token in doc:
        if token.pos_ == "ADJ" and token.lemma_ in weak_adj_patterns:
            original = token.text
            improved = weak_adj_patterns[token.lemma_]
            
            # Preserve capitalization
            if original[0].isupper():
                improved = improved.capitalize()
            
            if original in text:
                replacements.append((original, improved))
                print(f"DEBUG: AI adjective improvement: '{original}' → '{improved}'")
    
    return replacements


def improve_weak_phrases_with_ai(doc, text):
    """Use AI to identify and improve weak phrases."""
    replacements = []
    
    weak_phrases = {
        'responsible for': 'managed',
        'was part of': 'contributed to',
        'involved in': 'engaged in',
        'worked on': 'developed',
        'worked with': 'collaborated with',
        'in charge of': 'supervised',
        'dealt with': 'managed',
        'took care of': 'oversaw',
        'was able to': 'successfully',
        'tried to': 'strategically',
        'managed to': 'successfully',
        'had to': 'required to',
        'needed to': 'required to',
        'wanted to': 'sought to',
        'decided to': 'chose to',
        'team player': 'collaborative professional',
        'detail oriented': 'detail-focused',
        'hard working': 'dedicated',
        'self motivated': 'self-driven'
    }
    
    for phrase, improvement in weak_phrases.items():
        if phrase in text:
            replacements.append((phrase, improvement))
            print(f"DEBUG: AI phrase improvement: '{phrase}' → '{improvement}'")
        
        # Also check capitalized versions
        phrase_cap = phrase.capitalize()
        if phrase_cap in text:
            replacements.append((phrase_cap, improvement.capitalize()))
            print(f"DEBUG: AI phrase improvement: '{phrase_cap}' → '{improvement.capitalize()}'")
    
    return replacements


def remove_filler_words_with_ai(doc, text):
    """Use AI to identify and remove filler words."""
    replacements = []
    
    filler_words = ['very', 'really', 'quite', 'basically', 'actually', 'obviously', 'clearly', 'definitely', 'literally', 'just', 'simply', 'only', 'even', 'still', 'already', 'yet']
    filler_phrases = ['kind of', 'sort of', 'type of', 'a lot of', 'lots of', 'in order to', 'due to the fact that', 'for the purpose of', 'at this point in time']
    
    # Remove standalone filler words
    for filler in filler_words:
        patterns = [f' {filler} ', f'{filler} ', f' {filler}']
        for pattern in patterns:
            if pattern in text:
                replacement = pattern.replace(filler, '').strip()
                if replacement == '':
                    replacement = ' '
                replacements.append((pattern, replacement))
                print(f"DEBUG: AI filler removal: '{pattern}' → '{replacement}'")
    
    # Remove filler phrases
    for phrase in filler_phrases:
        if phrase in text:
            if phrase == 'in order to':
                replacements.append((phrase, 'to'))
            elif phrase == 'due to the fact that':
                replacements.append((phrase, 'because'))
            elif phrase == 'for the purpose of':
                replacements.append((phrase, 'to'))
            elif phrase == 'at this point in time':
                replacements.append((phrase, 'now'))
            else:
                replacements.append((phrase, ''))
            print(f"DEBUG: AI filler phrase removal: '{phrase}'")
    
    return replacements


def enhance_professional_language_with_ai(doc, text):
    """Use AI to enhance professional language."""
    replacements = []
    
    professional_upgrades = {
        'job': 'role',
        'company': 'organization',
        'boss': 'supervisor',
        'coworker': 'colleague',
        'teammate': 'team member',
        'customer': 'client',
        'buyer': 'client',
        'seller': 'vendor',
        'money': 'budget',
        'cash': 'revenue',
        'profit': 'earnings',
        'problem': 'challenge',
        'issue': 'matter',
        'stuff': 'materials',
        'things': 'elements',
        'guys': 'team members',
        'folks': 'individuals'
    }
    
    for token in doc:
        if token.lemma_ in professional_upgrades and token.text.lower() in professional_upgrades:
            original = token.text
            improved = professional_upgrades[token.text.lower()]
            
            # Preserve capitalization
            if original[0].isupper():
                improved = improved.capitalize()
            
            if original in text:
                replacements.append((original, improved))
                print(f"DEBUG: AI professional upgrade: '{original}' → '{improved}'")
    
    return replacements


def improve_lorem_ipsum_with_ai(text):
    """AI-powered Lorem Ipsum replacement with contextual content."""
    replacements = []
    
    lorem_replacements = {
        'lorem ipsum': 'professional experience',
        'Lorem ipsum': 'Professional experience',
        'LOREM IPSUM': 'PROFESSIONAL EXPERIENCE',
        'dolor sit amet': 'achievement excellence',
        'consectetur adipiscing': 'comprehensive expertise',
        'elit sed do': 'strategic execution',
        'eiusmod tempor': 'innovative solutions',
        'incididunt ut labore': 'dedicated performance',
        'dolore magna aliqua': 'exceptional results',
        'ut enim ad minim': 'strategic implementation',
        'veniam quis nostrud': 'professional excellence'
    }
    
    for lorem, replacement in lorem_replacements.items():
        if lorem in text:
            replacements.append((lorem, replacement))
            print(f"DEBUG: AI Lorem Ipsum replacement: '{lorem}' → '{replacement}'")
    
    return replacements


def get_basic_improvements(text):
    """Basic fallback improvements if AI processing fails."""
    replacements = []
    
    basic_replacements = {
        'good': 'excellent',
        'great': 'outstanding',
        'helped': 'assisted',
        'worked on': 'developed',
        'responsible for': 'managed',
        'very': '',
        'really': '',
        'lorem ipsum': 'professional experience'
    }
    
    for old, new in basic_replacements.items():
        if old in text:
            replacements.append((old, new))
            if old.capitalize() in text:
                replacements.append((old.capitalize(), new.capitalize() if new else ''))
    
    return replacements

def add_action_verbs(text, analysis_results):
    """
    Improve resume by adding strong action verbs.
    
    Args:
        text (str): The original resume text.
        analysis_results (dict): Resume analysis results.
        
    Returns:
        list: List of tuples (old_text, new_text) for replacement.
    """
    replacements = []
    
    # Common phrases to replace with action verbs
    phrases_to_replace = {
        'I was responsible for': 'I managed',
        'My responsibilities included': 'I led',
        'I helped with': 'I contributed to',
        'I worked on': 'I developed',
        'I was involved in': 'I participated in',
    }
    
    for old_phrase, new_phrase in phrases_to_replace.items():
        if old_phrase in text:
            replacements.append((old_phrase, new_phrase))
    
    return replacements

def optimize_keywords(text, analysis_results):
    """
    Optimize keywords in the resume based on industry standards.
    
    Args:
        text (str): The original resume text.
        analysis_results (dict): Resume analysis results.
        
    Returns:
        list: List of tuples (old_text, new_text) for replacement.
    """
    replacements = []
    
    # Basic keyword improvements
    keyword_improvements = {
        'computer skills': 'technical skills',
        'team player': 'collaborative',
        'detail oriented': 'detail-focused',
    }
    
    for old_phrase, new_phrase in keyword_improvements.items():
        if old_phrase in text.lower():
            replacements.append((old_phrase, new_phrase))
            replacements.append((old_phrase.title(), new_phrase.title()))
    
    return replacements

def improve_resume(input_path, output_dir, analysis_results):
    """
    Improve a resume based on analysis results.
    
    Args:
        input_path (str): Path to the original resume file.
        output_dir (str): Directory to save the improved resume.
        analysis_results (dict): Resume analysis results.
        
    Returns:
        tuple: (success, output_path) where success is a boolean indicating if the
               operation was successful, and output_path is the path to the improved resume.
    """
    try:
        # Extract file information
        file_name = os.path.basename(input_path)
        file_name_without_ext, ext = os.path.splitext(file_name)
        ext = ext.lower()
        
        # Create output path
        output_path = os.path.join(output_dir, f"{file_name_without_ext}_improved{ext}")
        
        # Extract text from the resume
        if ext == '.pdf':
            with fitz.open(input_path) as doc:
                text = ""
                for page in doc:
                    text += page.get_text()
        elif ext == '.docx':
            doc = docx.Document(input_path)
            text = ""
            for para in doc.paragraphs:
                text += para.text + "\n"
        elif ext == '.txt':
            with open(input_path, 'r', encoding='utf-8') as file:
                text = file.read()
        else:
            return False, None
        
        # Generate improvements
        replacements = []
        
        # Add weak language improvements
        weak_language_replacements = improve_weak_language(text, analysis_results)
        replacements.extend(weak_language_replacements)
        
        # Add action verb improvements
        action_verb_replacements = add_action_verbs(text, analysis_results)
        replacements.extend(action_verb_replacements)
        
        # Add keyword optimizations
        keyword_replacements = optimize_keywords(text, analysis_results)
        replacements.extend(keyword_replacements)
        
        # Remove duplicates while preserving order
        unique_replacements = []
        seen = set()
        for old_text, new_text in replacements:
            if (old_text, new_text) not in seen and old_text != new_text and old_text.strip() and new_text.strip():
                unique_replacements.append((old_text, new_text))
                seen.add((old_text, new_text))
                print(f"DEBUG: Will replace '{old_text}' → '{new_text}'")
        
        print(f"DEBUG: Total unique replacements: {len(unique_replacements)}")
        
        print(f"DEBUG: Applying {len(unique_replacements)} improvements to {ext} file")
        
        # Apply improvements based on file type
        if ext == '.pdf':
            print("DEBUG: PDF files are not supported for improvements. Please use DOCX or TXT.")
            return False, "PDF files are not supported for text improvements. Please convert to DOCX format."
        elif ext == '.docx':
            success = replace_text_in_docx(input_path, output_path, unique_replacements)
        elif ext == '.txt':
            success = replace_text_in_txt(input_path, output_path, unique_replacements)
        else:
            print(f"DEBUG: Unsupported file type: {ext}")
            return False, f"Unsupported file type: {ext}. Please use DOCX or TXT files."
        
        if success:
            return True, output_path
        else:
            return False, None
            
    except Exception as e:
        print(f"Error improving resume: {str(e)}")
        return False, None